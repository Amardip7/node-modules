export default function useWrappedRefWithWarning(ref: any, componentName: any): any;
