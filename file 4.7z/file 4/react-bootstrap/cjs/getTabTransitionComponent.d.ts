import { TransitionComponent } from '@restart/ui/types';
import { TransitionType } from './helpers';
export default function getTabTransitionComponent(transition?: TransitionType): TransitionComponent | undefined;
