/// <reference types="react" />
export default function getInitialPopperStyles(position?: React.CSSProperties['position']): Partial<React.CSSProperties>;
