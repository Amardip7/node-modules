import { SSRProvider } from '@restart/ui/ssr';
import type { SSRProviderProps } from '@restart/ui/ssr';
export type { SSRProviderProps };
export default SSRProvider;
