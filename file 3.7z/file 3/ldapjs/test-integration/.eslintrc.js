module.exports = {
  rules: {
    'no-shadow': 'off'
  }
}
