module.exports = {
  parserOptions: {
    ecmaVersion: 'latest'
  },

  rules: {
    'no-shadow': 'off'
  }
}
