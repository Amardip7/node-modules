declare function isNegativeZero(number: unknown): number is -0;

export = isNegativeZero;