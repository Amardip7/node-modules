declare function ToObject<T = {}>(value: T extends object ? T : {}): T extends object ? T : object;

export = ToObject;